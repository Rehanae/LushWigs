# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lushwigs']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['lushwigs = lushwigs.app:main']}

setup_kwargs = {
    'name': 'lushwigs',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Ren',
    'author_email': 'jessjones.v15@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
